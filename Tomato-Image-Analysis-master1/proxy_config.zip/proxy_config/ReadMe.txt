Install libraries in Anaconda

*** What to do:
Copy the configuration files in the folder "config_files" into the correct folders:
1. Delete the environment variable "http_proxy" if it exists. This is a user-defined environment variable, NOT system-wide variable, i.e. you do not have to be admin to delete this variable.
2. Copy .condarc to C:\Users\YOUR-USER-NAME\
3. Copy pip.ini to C:\Users\YOUR-USER-NAME\pip (create the pip folder if it does not already exist there)

In Anaconda prompt: use "conda install" or "pip install" to install libraries.


*** Notes:
The number of available libraries using "conda install" is very limited. For further libraries, use "pip install".
